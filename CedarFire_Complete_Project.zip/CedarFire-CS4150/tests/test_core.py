import sys,tempfile,unittest,json,datetime as dt
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
import core

class CoreTests(unittest.TestCase):
 def test_radius(self):
  self.assertEqual(core.distance(*core.CENTER),0)
  self.assertGreater(core.distance(40.76,-111.89),core.RADIUS)
  self.assertEqual(core.RADIUS,50)
  self.assertGreater(core.distance(core.CENTER[0]+1,core.CENTER[1]),core.RADIUS)
 def test_historical_records_match_radius(self):
  records=json.loads((core.ROOT/'data/fires.json').read_text())
  self.assertTrue(records)
  self.assertTrue(all(core.distance(r['latitude'],r['longitude'])<=core.RADIUS for r in records))
  self.assertEqual(json.loads((core.ROOT/'data/provenance.json').read_text())['radius_miles'],core.RADIUS)
 def test_no_future_weather_leakage(self):
  dates=pd.date_range('2024-01-01','2024-02-01');w=pd.DataFrame({k:np.arange(len(dates),dtype=float) for k in ['T2M_MAX','RH2M','WS10M','PRECTOTCORR']},index=dates)
  target=pd.DatetimeIndex(['2024-02-01']);x=core.features(target,w)
  expected=w.loc['2024-01-18':'2024-01-24'].mean().iloc[0]
  self.assertAlmostEqual(x[0,2],expected)
  w.loc['2024-01-25':]=9999
  np.testing.assert_equal(x,core.features(target,w))
 def test_missing_weather_withheld(self):
  p=core.PredictionAgent().predict({},dt.date(2026,11,19));self.assertEqual(p['status'],'withheld');self.assertNotIn('probability',p)
 def test_model_probability(self):
  p=core.PredictionAgent().predict({'weather':{'features':[0,1,15,30,4,0]}},dt.date(2026,11,19));self.assertTrue(0<=p['probability']<=1)
 def test_dedup_and_ack(self):
  with tempfile.TemporaryDirectory() as td:
   with patch.object(core,'ROOT',Path(td)):
    (Path(td)/'data').mkdir();a=core.AlertAgent();first=a.emit('test','same','title','body',True);self.assertIsNone(a.emit('test','same','title','body',True));a.acknowledge(first['id']);self.assertTrue(a.history()[0]['acknowledged'])
 def test_official_warning_not_assumed_local(self):
  with tempfile.TemporaryDirectory() as td:
   with patch.object(core,'ROOT',Path(td)):
    (Path(td)/'data').mkdir();a=core.AlertAgent();a.evaluate({'warnings':[{'scope':'state context — exact overlap unverified'}]},{});self.assertEqual(a.history(),[])
 def test_polygon_overlap(self):
  self.assertTrue(core.geometry_intersects({'type':'Polygon','coordinates':[[[-114,37],[-112,37],[-112,38],[-114,38],[-114,37]]]}))
  self.assertFalse(core.geometry_intersects({'type':'Polygon','coordinates':[[[-121,40],[-120,40],[-120,41],[-121,41],[-121,40]]]}))
 def test_stale_incident_no_alert(self):
  with tempfile.TemporaryDirectory() as td:
   with patch.object(core,'ROOT',Path(td)):
    (Path(td)/'data').mkdir();a=core.AlertAgent();a.evaluate({'incidents':[{'discovered':1}]},{});self.assertEqual(a.history(),[])
if __name__=='__main__':unittest.main()
