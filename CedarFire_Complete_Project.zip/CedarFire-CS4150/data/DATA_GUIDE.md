# Project CSV files

These files were exported from the real official-source downloads included in this project. They are not synthetic examples.

- `US Forest Service/fire_history_50_miles.csv`: individual US Forest Service wildfire reports within 50 miles of Cedar City, Utah, from 2000–2024. `discovery_date` is the original Unix timestamp in milliseconds. `discovery_day` is the readable date. `distance_miles` is the calculated distance from the Cedar City center. `fire_size` is the final reported size in acres and is **not a prediction input**.
- `NASA/weather_history.csv`: daily NASA POWER readings at the Cedar City center point. `T2M_MAX`: maximum temperature (C); `RH2M`: relative humidity (%); `WS10M`: wind at 10 m (m/s); `PRECTOTCORR`: precipitation (mm/day). Dates are UTC.
- `Model Data/training_data.csv`: one row per target day. `fire_reported` is 1 if at least one wildfire discovery was recorded inside the circle that day, otherwise 0. The four weather feature columns are seven-day means from target day T−14 through T−8. `sin_day` and `cos_day` encode season. `split` identifies training, model selection, calibration, and held-out test years.
- `Model Data/test_predictions.csv`: actual labels and predicted probabilities for the final test years, 2022–2024.

Original sources and query details: `provenance.json`, the NASA metadata in `weather_history.json`, and the Sources section in `../README.md`. JSON originals are retained so the CSV conversion can be reproduced using `python export_data.py`.

These labels indicate reported discovery, not exact ignition time. Missing reports can produce incorrect negative labels. Weather at one point does not represent every location within 50 miles.
